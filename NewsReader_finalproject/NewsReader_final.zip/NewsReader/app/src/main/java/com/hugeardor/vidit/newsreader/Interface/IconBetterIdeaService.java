package com.hugeardor.vidit.newsreader.Interface;

import com.hugeardor.vidit.newsreader.Model.IconBetterIdea;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Url;

/**
 * Created by vidit on 19/12/17.
 */

public interface IconBetterIdeaService {
    @GET
    Call<IconBetterIdea> getIconUrl(@Url String url) ;



}
