package com.hugeardor.vidit.newsreader.Interface;

import android.view.View;

/**
 * Created by vidit on 19/12/17.
 */

public interface ItemClickListener {

    void onClick(View view , int position , boolean isLongClick) ;



}
