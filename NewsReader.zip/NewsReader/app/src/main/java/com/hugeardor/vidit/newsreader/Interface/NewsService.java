package com.hugeardor.vidit.newsreader.Interface;

import android.telecom.Call;


import com.hugeardor.vidit.newsreader.Model.WebSite;

import retrofit2.http.GET;

/**
 * Created by vidit on 19/12/17.
 */

public interface NewsService {

    @GET("v1/sources?language=en")
    retrofit2.Call<WebSite> getSources();




}
