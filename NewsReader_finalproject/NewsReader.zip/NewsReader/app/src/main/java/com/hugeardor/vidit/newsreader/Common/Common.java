package com.hugeardor.vidit.newsreader.Common;

import com.hugeardor.vidit.newsreader.Interface.IconBetterIdeaService;
import com.hugeardor.vidit.newsreader.Interface.NewsService;
import com.hugeardor.vidit.newsreader.Model.IconBetterIdea;
import com.hugeardor.vidit.newsreader.Remote.IconBetterIdeaClient;
import com.hugeardor.vidit.newsreader.Remote.RetrofitClient;

/**
 * Created by vidit on 19/12/17.
 */

public class Common {

    private  static final  String  BASE_URL ="https://newsapi.org/" ;

    public static final String API_KEY = "32471f020e5e4142a8b579e07bc34486" ;



    public static NewsService getNewsService()
    {
        return RetrofitClient.getClient(BASE_URL).create(NewsService.class) ;
    }

    public static IconBetterIdeaService getIconService()
    {
        return IconBetterIdeaClient.getClient().create(IconBetterIdeaService.class) ;
    }

    //https://newsapi.org/v1/articles?source=the-verge&apiKey=32471f020e5e4142a8b579e07bc34486

    public static String getAPIUrl (String source , String sortBy , String apiKEY )
    {
        StringBuilder apiUrl = new StringBuilder("https://newsapi.org/v1/articles?source=") ;
        return apiUrl.append(source)
                .append("&sortBy=")
                .append(sortBy)
                .append("&apiKey=").append(apiKEY).toString() ;


    }
}
